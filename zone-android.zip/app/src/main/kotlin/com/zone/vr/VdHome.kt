package com.zone.vr

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** The "home screen" that lives on the floating virtual display. Apps opened from here stay on that display. */
class VdHome : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF0F1122.toInt())

        val title = TextView(this)
        title.text = "Zone"
        title.setTextColor(Color.WHITE)
        title.textSize = 22f
        title.setPadding(36, 24, 36, 12)
        root.addView(title)

        val grid = GridView(this)
        grid.numColumns = 6
        grid.stretchMode = GridView.STRETCH_COLUMN_WIDTH
        grid.verticalSpacing = 20
        grid.adapter = object : BaseAdapter() {
            override fun getCount(): Int = apps.size
            override fun getItem(position: Int): Any = apps[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val ri = apps[position]
                val cell = LinearLayout(this@VdHome)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER_HORIZONTAL
                cell.setPadding(6, 6, 6, 6)
                val img = ImageView(this@VdHome)
                img.setImageDrawable(ri.loadIcon(pm))
                img.layoutParams = LinearLayout.LayoutParams(120, 120)
                val tv = TextView(this@VdHome)
                tv.text = ri.loadLabel(pm)
                tv.setTextColor(Color.WHITE)
                tv.textSize = 14f
                tv.gravity = Gravity.CENTER
                tv.maxLines = 1
                tv.ellipsize = TextUtils.TruncateAt.END
                cell.addView(img)
                cell.addView(tv)
                return cell
            }
        }
        grid.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
            val i = pm.getLaunchIntentForPackage(apps[pos].activityInfo.packageName)
            if (i != null) startActivity(i)
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }
}
